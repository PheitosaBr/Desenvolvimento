// script.js
// Script para o menu dropdown responsivo
document.addEventListener("DOMContentLoaded", function () {
    const dropdown = document.querySelector(".dropdown");
    const menuToggle = dropdown.querySelector("a.menu-toggle"); // O link do menu
    const dropdownMenu = dropdown.querySelector(".dropdown-menu");

    // Abre o menu ao passar o mouse no desktop
    dropdown.addEventListener("mouseenter", function () {
        if (window.innerWidth >= 769) { // Só ativa hover no desktop
            dropdownMenu.classList.add("show");
        }
    });

    dropdown.addEventListener("mouseleave", function () {
        if (window.innerWidth >= 769) {
            dropdownMenu.classList.remove("show");
        }
    });

    // Abre e fecha o menu ao clicar no tablet/mobile
    menuToggle.addEventListener("click", function (event) {
        event.preventDefault();
        dropdownMenu.classList.toggle("show"); // Alterna visibilidade no clique
    });

    document.addEventListener("click", function (event) {
        if (!dropdown.contains(event.target)) {
            dropdownMenu.classList.remove("show"); // Fecha se clicar fora
        }
    });
});

